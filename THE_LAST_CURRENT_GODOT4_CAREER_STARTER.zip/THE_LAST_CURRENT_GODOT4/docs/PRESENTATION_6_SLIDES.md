# Suggested 6-slide final defense

1. **Title:** THE LAST CURRENT — Mustafin Arlan / Tokmagambet Beknazar. Background: original in-game 3D ocean scene (capture after engine test).
2. **Problem:** Navigate between islands under inaccurate storm reports and limited resources. Goal: minimize expected cost/risk, safely complete a contract.
3. **System diagram:** Lookout signal → Bayesian posterior → A* route weights → One-step MDP action advice → player interaction.
4. **A* & Bayes live example:** route overlay, grid blocking, prior=0.30, alert posterior≈0.6792, clear posterior≈0.0763.
5. **MDP + test results:** reward table, EU(sail) vs EU(anchor); 15/15 Python tests (Godot smoke test result must be added by students).
6. **Demo + limitations + next steps:** animated world / career shop / Python trace / limits and future improvements.

**Do not claim** the Windows executable, full real-world maritime deployment, or engine smoke tests are complete until you have verified them.

# Oral defense notes — both students should understand all algorithms

**Arlan / introductory problem statement (~1 min):**

> Our project simulates risk-aware maritime navigation. A ship needs to reach islands, recover valuable cargo and return to port. Obstacles and noisy lookout signals make the shortest geometric route potentially unsafe. We combine A*, Bayesian inference and one-step MDP to help a navigator plan efficiently under uncertainty.

**Beknazar / system explanation (~1 min):**

> First, Bayes updates the probability of a dangerous storm after an imperfect observation. Then A* uses those risk estimates as movement costs to find a route through a grid. Finally, a one-step Markov Decision Process compares the expected rewards of sailing and anchoring. Pressing G applies the resulting recommendation. The AI Lab shows inputs, steps and outputs.

### Key Q&A (practice independently)

**Q: Why not just BFS?** A: BFS minimizes the number of steps on an unweighted grid. A* can optimize travel costs when cells have different costs.

**Q: What is h(n)?** A: The estimated remaining cost; here Manhattan distance, which is admissible because movement is four-directional with cost ≥1.

**Q: What is a posterior?** A: The probability after updating prior belief with new sensor evidence using Bayes.

**Q: Why isn't ALERT equal to 100% danger?** A: The lookout can produce false alarms, so we calculate the posterior using both sensitivity and false-positive rates.

**Q: Are you training a model?** A: No. We use search, probabilistic inference and expected-reward planning; a trained neural network is not required.

**Q: Is it a full MDP policy?** A: No. It is a two-state, two-action one-step comparison, which is permitted by the detailed guidelines.

**Q: What if the ship runs out of supplies?** A: It can still move slowly to prevent a softlock; low supplies also lowers its expected sail reward.

**Q: What do you test?** A: Mathematical expected values, path length and weighted costs, reachability, and input/observation scenarios. Runtime UI and Windows export also need a smoke test before submission.

**Q: Why a pirate theme if this is a real-world problem?** A: The fictional setting makes autonomous maritime route planning more engaging. The underlying problem—navigation under incomplete and noisy observations—is real.

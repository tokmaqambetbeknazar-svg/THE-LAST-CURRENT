# AI usage declaration — draft to review and customize

Generative AI (ChatGPT by OpenAI) assisted with concept development, GDScript scaffolding, algorithm reference code, UI structure and draft documentation. The team must independently run the project in Godot, review every algorithm and source file, test the export on Windows, and correct any errors before making final claims. AI-generated material should be disclosed according to course requirements. No copyrighted One Piece graphics or audio assets were included.

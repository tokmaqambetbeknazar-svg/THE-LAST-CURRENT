# Test Results — Python mathematical reference only

Test command (run at project root):

```shell
python -m unittest discover -s tests -v
```

**15/15 passed** in the authoring container (Godot engine and Windows export templates unavailable). Coverage:

- 5 Bayesian checks (alert/clear, normalization extremes, invalid values)
- 4 MDP checks (high vs low risk, expected rewards, low supplies)
- 4 A* checks (empty grid, blocked map, expensive shortcut, path adjacency)
- 2 map integration checks (all port pairs, increasing risk does not decrease weighted cost)

You can reproduce a fixed sample with `python ai_reference.py`.

Before claiming completion of the project rubric, **still run**:

- [ ] Open `scenes/Main.tscn` in Godot 4; check Output/Debugger for parser errors.
- [ ] Start career and accept a contract.
- [ ] Sail to a target dock, collect cargo and return to Haven.
- [ ] Use Q, F, G, T; show values in AI Lab.
- [ ] Confirm gold and upgrade persist after restarting the project.
- [ ] Finish all five missions.
- [ ] Export a Windows `.exe` and launch it on the submission laptop.

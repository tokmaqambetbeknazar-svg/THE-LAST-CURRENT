# THE LAST CURRENT — Legends of the Sea

**Godot 4 3D adventure · Career prototype v0.1 · QAIRU AI Fundamentals**  
**Authors on the game menu:** Mustafin Arlan · Tokmagambet Beknazar

> This archive is a **Godot source project**, not an HTML page or prebuilt Windows executable. The scene, 3D objects, animated ocean, ships, islands and GUI are created procedurally using original GDScript. No copyrighted One Piece assets are included.

## Windows: how to start

1. Install **Godot Engine 4.x (standard / GDScript)** from https://godotengine.org/download/windows/ (tested code *targets* Godot 4.3+, but a Godot runtime was unavailable in the project-creation environment).
2. Extract this ZIP to a normal folder such as `Documents\TheLastCurrent`.
3. Open Godot → **Import** → choose `THE_LAST_CURRENT_GODOT4/project.godot` → **Import & Edit**.
4. Allow the editor to import the `.wav` resources; select `scenes/Main.tscn` if needed.
5. Press **F6** for the open scene or **F5** for the project; the cinematic main menu should appear.
6. Choose **START NEW CAREER** → **ACCEPT THE NEXT CONTRACT**.

### Export to .exe on Windows

In Godot: **Project → Export → Add → Windows Desktop**. If asked, install the Godot Export Templates that match your editor version. Set an export path such as `build/TheLastCurrent.exe`, then **Export Project**. An EXE is **not included** in the ZIP because the Godot editor and Windows export templates were not available to run an actual export here.

## Controls

| Input | Action |
|---|---|
| W / Up | Accelerate |
| S / Down | Reverse / brake |
| A, D / Left, Right | Steer |
| E | Collect a relic at the destination; deliver it back at the home dock |
| Q | Use a limited lookout scan and run Bayesian inference |
| G | **Execute MDP advice**: Sail (temporary speed bonus) or Anchor (5 seconds) |
| T | Show/hide the A* route waypoints |
| F | Show/hide detailed AI Laboratory calculations |
| R | Recalculate route |
| Space (hold) | Anchor/wait: slow to a stop and regenerate a little supplies |
| M | Music on/off |
| Esc | Pause / resume |

### Goal

Travel from **Haven Port** to the marked island, approach the glowing dock, press **E** to recover the relic, then return to Haven Port and press **E**. You earn gold and reputation; invest in **Engine**, **Hull** or **Sonar** upgrades in the port. Finish **five contracts** to reach the Legendary Navigator rank.

### What to expect from this release

- Stylized **3D sea** with a moving wave shader, ships, palm islands, buildings, reefs, storm clouds and roaming rival vessels.
- **Third-person controls**, camera follow, bobbing ship hull, animated sails, drifting clouds, route markers and treasure pickups.
- **Career**: five missions, shipyard upgrades, gold, rank, persistent local save (`user://the_last_current_career.json`).
- Scans can be wrong. The map contains two storm fronts with uncertain conditions. The lookout uses Bayes, routes use A*, and the navigator uses an MDP.
- Original generated ocean ambience, synthesized instrumental theme and sound effects in `assets/audio`.
- A reproducible **Python reference**, unit tests, a technical report and a presentation outline for course assessment.

This is a **playable first milestone**, not a finished commercial campaign. Full runtime/graphics validation inside Godot and Windows `.exe` export are still outstanding. In particular, performance, UI scaling on different displays, and gameplay pacing must be checked inside the actual engine.

## AI implementation (three complementary course topics)

1. **Bayesian inference** (`scripts/ai_engine.gd:posterior`) receives a prior `P(storm)`, lookout sensitivity `0.84`, false-positive rate `0.17`, and a noisy `ALERT`/`CLEAR`. It computes `P(storm|reading)`.
2. **A*** (`scripts/ai_engine.gd:astar`) navigates a 19×19 grid with 4-neighbor movement and Manhattan heuristic. Reefs/islands are blocked; cells near storms receive extra movement cost based on the current Bayesian beliefs. The in-world golden route is reconstructed from the actual returned path.
3. **One-step MDP** (`scripts/ai_engine.gd:mdp_decision`) uses two states (calm/dangerous), two actions (sail/anchor), hypothetical rewards (sail calm +11, sail dangerous −23, anchor −3) and the Bayesian risk as the state belief. Press `G` to apply its suggested action in-game.

**Algorithm pipeline:** lookout observation → posterior probability → updated storm weights for A* → optimal route and immediate MDP advice. AI Lab (`F`) displays input, calculations, output and the decision rationale. No trained ML model is claimed.

## Reproducing the academic calculations

From the extracted project root, with Python 3.8+ (no external packages):

```bash
python ai_reference.py
python -m unittest discover -s tests -v
```

The tests check Bayesian normalization, MDP choices, weighted A* routes and reachability of all port pairs. Results from the creation environment: **15/15 reference tests passed**. These **are not substitutes** for a Godot-engine smoke test.

## Folders

- `project.godot` / `scenes/Main.tscn`: load into Godot.
- `scripts/main.gd`: career logic, 3D ship steering, UI, game loop.
- `scripts/world_builder.gd`: procedurally generated original 3D art and animation.
- `scripts/ai_engine.gd`: actual GDScript implementations.
- `assets/audio`: original synthesized WAV ambience, soundtrack and effects.
- `ai_reference.py`, `tests/`: reproducible Python reference and tests.
- `docs/`: requirements checklist, technical report draft, defense notes and future work.

## Known constraints

- Stylized low-poly world, not an AAA realistic pirate title.
- Progress saves upon finishing a voyage and making upgrades; exiting during a voyage returns to port.
- Routes use an **abstract 2D grid under the 3D world**. Movement happens in continuous 3D but the planned path is an approximate tile sequence, not a full ship physics simulation.
- Storm priors and likelihoods are **assumptions** for an educational toy model.
- MDP is a one-step expected-reward choice, not deep reinforcement learning.
- Ship hull cannot fall below 10 points and supplies-depleted vessels can limp at reduced speed, to prevent softlocks.

## Assessment deliverables still requiring your action

- Push the tested project to **your GitHub repository** (do not overwrite existing `Campus_Relay` until reviewed).
- Run and screen-record a successful **Godot/Windows live demo**, then export a `.exe` if required.
- Complete the **team contribution statement** with your real contributions and submit a **5–7 slide PowerPoint** and **2–3 minute demo video**.
- Review and personalize `docs/TECHNICAL_REPORT.md`, `docs/AI_USAGE_DECLARATION.md` and the defense notes.

# Team Contribution Statement — fill out only after confirming actual work

- **Mustafin Arlan:** [Specify work actually completed, not planned responsibilities.]
- **Tokmagambet Beknazar:** [Specify work actually completed, not planned responsibilities.]
- **Joint review:** [List the tests both students ran, algorithms they understood and portions of the live demo they can explain.]

Both members should be able to answer individual AI-algorithm questions.

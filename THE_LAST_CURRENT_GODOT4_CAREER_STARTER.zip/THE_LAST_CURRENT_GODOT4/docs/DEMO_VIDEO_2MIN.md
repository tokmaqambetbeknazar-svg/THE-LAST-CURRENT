# 2–3-minute live demo video script (record from the Godot runtime)

0:00–0:15 — Show cinematic title, authors, start career.

0:15–0:35 — Accept first contract, point out gold and shipyard upgrades.

0:35–1:05 — Sail on the 3D ocean. Explain the golden A* route and obstacles.

1:05–1:30 — Press Q. Open AI Lab F. State the prior, likelihood and new Bayesian posterior.

1:30–1:50 — Show MDP expected rewards and press G to execute its chosen action.

1:50–2:25 — Dock at target, collect relic with E, return to Haven and receive gold.

2:25–2:45 — Buy an upgrade. Summarize the real-world problem and demo algorithm reproducibility.

Record the real project and do not fabricate gameplay screenshots.
